<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'sofa1_wp' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '}Smb<`R~xS[P)n4b(MCP}4VUog._]Tt/@CaCRD LoLTw{[dU}Adn]??+[{x?;Z[h' );
define( 'SECURE_AUTH_KEY',  'be%/M^S*&ZDyD_;#||$W`K$)cW~od7M7O<:T#8B3yiQO&u[v2e/*E%eHUj;|Ft,6' );
define( 'LOGGED_IN_KEY',    '/d#%0:}}y}!8UhdF?S;?FN7U0jH.`Nm;H2avUOx[/J R}*jg5RB9 @I!P@y=x7X*' );
define( 'NONCE_KEY',        '}V&<1I0WrVZU5pL[*{FR Yw(PrPs9@^xiV*P<N?.bW9~Fqp~@MA]p?&BQ.TlZ,_P' );
define( 'AUTH_SALT',        '1wv.*PNjNG-3^u;^{mgKf/U-WfjQ~*<^n|c!G<B<BvD3KRN[+a1vS_SUR;W~$eV>' );
define( 'SECURE_AUTH_SALT', '+ZD#)?LhoQty]t{ @zD?fo%A8~mWw~dzz9Zfm91q*fP+N?aD$7/oo6y<{M/duBGv' );
define( 'LOGGED_IN_SALT',   'fOk,S))HN;*Z+O,m)u{yI4/B*N-ywa/%xNGSV=[wh}lIm@2 e~w2o2BRN8d-jPd-' );
define( 'NONCE_SALT',       'R[ak9~s**(4c<4bbyW@OA9$Q6QVOGoVF5Au<K0nK4r?Hh+h7OD]z28|0:GO:C0%b' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
